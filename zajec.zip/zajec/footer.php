</div>
		<!-- end #content -->
		<div id="sidebar">
			<ul>
				<li>
					<h2>Meni</h2>
					<ul>
						<li><a href="ad_add.php">Dodaj oglas</a></li>
						<li><a href="ad_list.php">Preglej oglase</a></li>
						<li><a href="my_offers.php">Moja ponudba</a></li>
						<li><a href="categories_list.php">Preglej kategorije</a></li>
						<!--<li><a href="#">Urnanet non molestie semper</a></li>
						<li><a href="#">Proin gravida orci porttitor</a></li>-->
					</ul>
				</li>				
			</ul>
		</div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	<!-- end #page --> 
</div>
<div id="footer">
	<p>Copyright (c) 2012 Sitename.com. All rights reserved. Design by <a href="http://www.freecsstemplates.org">FCT</a>. Photos by <a href="http://fotogrph.com/">Fotogrph</a>.</p>
</div>
<!-- end #footer -->
</body>
</html>